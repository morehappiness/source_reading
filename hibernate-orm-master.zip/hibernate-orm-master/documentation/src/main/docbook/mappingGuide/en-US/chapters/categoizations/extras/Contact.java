public class Contact {
	private Integer id;
	private Name name;
	private String notes;
	private URL website;
	private boolean starred;
	// getters and setters ommitted
}

public class Name {
	private String first;
	private String middle;
	private String last;
	// getters and setters ommitted
}
