@Entity
public class Product {
	@Id
	private Integer id;
	private String sku;
	private String name;
	private String description;
}