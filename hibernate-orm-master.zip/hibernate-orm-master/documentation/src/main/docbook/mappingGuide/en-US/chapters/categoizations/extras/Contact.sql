create table Contact (
	id INTEGER NOT NULL,
	first_name VARCHAR,
	middle_name VARCHAR,
	last_name VARCHAR,
	notes VARCHAR,
	starred BIT,
	website VARCHAR
)