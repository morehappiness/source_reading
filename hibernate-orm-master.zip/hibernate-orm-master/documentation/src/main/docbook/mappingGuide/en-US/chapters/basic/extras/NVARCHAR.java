@Entity
public class Product {
	...
	@Basic
	@Nationalized
	public String description;
	...
}