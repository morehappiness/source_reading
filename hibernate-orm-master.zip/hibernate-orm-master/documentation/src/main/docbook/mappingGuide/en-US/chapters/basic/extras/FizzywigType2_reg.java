MetadataSources metadataSources = ...;

metadataSources.getMetaDataBuilder()
		.applyBasicType( FizzwigType2.KEYS, FizzwigType2.INSTANCE )
		...