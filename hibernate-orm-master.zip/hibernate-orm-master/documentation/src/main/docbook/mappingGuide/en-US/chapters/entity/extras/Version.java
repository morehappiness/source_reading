@Entity
public class Course {
	@Id
	private Integer id;
	@Version
	private Integer version;
	...
}