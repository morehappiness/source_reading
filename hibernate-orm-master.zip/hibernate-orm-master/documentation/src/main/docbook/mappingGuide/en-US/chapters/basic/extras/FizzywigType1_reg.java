MetadataSources metadataSources = ...;

metadataSources.getMetaDataBuilder()
		.applyBasicType( FizzwigType1.INSTANCE )
		...