INSERT INTO Product ("name", "number", id)
VALUES ('Mobile phone', '123-456-7890', 1)