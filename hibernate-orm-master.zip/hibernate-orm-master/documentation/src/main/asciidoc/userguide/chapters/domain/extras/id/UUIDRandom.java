@Entity
public class MyEntity {

    @Id
    @GeneratedValue
    public UUID id;

    ...
}